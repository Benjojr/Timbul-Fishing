"""Composition root: satu-satunya tempat yang tahu implementasi konkret."""
import argparse
import socket
import threading
import time
import webbrowser

from werkzeug.serving import run_simple

from bukti_tf.config import database_path, locate_tesseract
from bukti_tf.core.extractor import ReceiptExtractor
from bukti_tf.core.report_calculator import DailyReportCalculator
from bukti_tf.core.settlement_service import SettlementService
from bukti_tf.core.transfer_checker import TransferChecker
from bukti_tf.infra.bca_parser import BcaParser
from bukti_tf.infra.pdf_month_exporter import PdfMonthExporter
from bukti_tf.infra.pillow_preprocessor import PillowThresholdPreprocessor
from bukti_tf.infra.sqlite_repository import SqliteDailyRecordRepository
from bukti_tf.infra.tesseract_engine import TesseractOcrEngine
from bukti_tf.infra.txt_exporter import TxtExporter
from bukti_tf.web.app import create_app

DEFAULT_PORT = 8765


def build_app(lan: bool = False):
    tesseract_cmd, tessdata_dir = locate_tesseract()
    extractor = ReceiptExtractor(
        preprocessor=PillowThresholdPreprocessor(),
        ocr=TesseractOcrEngine(tesseract_cmd, tessdata_dir),
        parsers=[BcaParser()],
    )
    repository = SqliteDailyRecordRepository(database_path())
    calculator = DailyReportCalculator()
    service = SettlementService(repository, calculator, TransferChecker())
    return create_app(extractor, TxtExporter(), calculator, repository, service,
                      PdfMonthExporter(usaha="Timbul Fishing"), lan=lan)


def _free_port(host: str, start: int) -> int:
    for port in range(start, start + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:  # tidak ada yang mendengarkan
                return port
    raise SystemExit(f"Port {start}-{start + 19} semuanya terpakai.")


def _lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))  # tidak mengirim paket apa pun
            return s.getsockname()[0]
    except OSError:
        return "IP-komputer-ini"


def _wait_ready(port: int, timeout: float = 10.0) -> None:
    end = time.time() + timeout
    while time.time() < end:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                return
        time.sleep(0.05)


def _open_window(url: str) -> bool:
    """Tampilkan UI di jendela aplikasi sendiri. False jika pywebview tidak tersedia."""
    try:
        import webview
    except ImportError:
        return False
    webview.settings["ALLOW_DOWNLOADS"] = True   # PDF / .txt boleh diunduh
    webview.create_window("BuktiTF · Rekap & Verifikasi Transfer", url,
                          width=1240, height=820, min_size=(900, 650))
    webview.start()   # blok sampai jendela ditutup
    return True


def main() -> None:
    ap = argparse.ArgumentParser(description="BuktiTF - rekap harian & verifikasi transfer")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--lan", action="store_true",
                    help="izinkan HP/komputer lain di Wi-Fi yang sama membuka aplikasi "
                         "(tanpa kata sandi!)")
    ap.add_argument("--browser", action="store_true",
                    help="buka di browser, bukan di jendela aplikasi")
    ap.add_argument("--no-window", action="store_true",
                    help="hanya jalankan server (tanpa jendela/browser)")
    args = ap.parse_args()

    host = "0.0.0.0" if args.lan else "127.0.0.1"
    port = _free_port(host, args.port)
    url = f"http://localhost:{port}"
    app = build_app(lan=args.lan)
    serve = lambda: run_simple(host, port, app, threaded=True, use_reloader=False)

    if args.lan:
        print(f"Dari HP/komputer lain di jaringan yang sama: http://{_lan_ip()}:{port}")
        print("Peringatan: siapa pun di jaringan ini bisa membuka dan mengubah data.")

    if args.no_window or args.browser:
        if args.browser:
            threading.Timer(0.8, webbrowser.open, args=(url,)).start()
        print(f"BuktiTF berjalan di {url}   (Ctrl+C untuk berhenti)")
        serve()
        return

    threading.Thread(target=serve, daemon=True).start()   # server hidup selama jendela terbuka
    _wait_ready(port)
    if not _open_window(url):
        print("pywebview belum terpasang (pip install pywebview); membuka di browser.")
        webbrowser.open(url)
        print(f"BuktiTF berjalan di {url}   (Ctrl+C untuk berhenti)")
        threading.Event().wait()


if __name__ == "__main__":
    main()
